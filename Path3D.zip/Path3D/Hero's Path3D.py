# -*- coding: utf-8 -*-
"""
Hero's Path3D

Created on Sat Oct 14 22:25:56 2023

Reads 720p videos of TOTK and records the minimap coordinates, using linear
transformations.

Be sure to edit the path variables in cells 2 and 3 appropriately, and 

@author: Juke
"""
# These are all that's required to save to csv or numpy arrays
import cv2
import numpy as np
from numpy import save, savetxt, load

# Optional for plotting
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d

# Optional for animating a rotating 3d plot
from matplotlib import animation
from matplotlib.animation import PillowWriter

# %% Path  and file name variables

# Input path to video
video_path = 'C:\\Users\\Juke\\Documents\\Z train\\unsorted\\spiral.mp4'

# Make sure this can find the npy files for the transformation matrices
matrix_path = 'C:\\Users\\Juke\\Desktop\\Path3D\\Matrices\\'

# Input where the csv's and gif are to be saved
save_path = 'C:\\Users\\Juke\\Desktop\\Path3D\\'

# File names for raw and corrected trajectories
csv_name = 'Trajectory.csv'
csv_corrected_name = 'Corrected Trajectory.csv'

npy_name = 'Trajectory.npy'
npy_corrected_name = 'Corrected Trajectory.npy'

# %% Load transformation matrices

x1m = load(matrix_path + 'x_1 linear.npy')
x2m = load(matrix_path + 'x_2 linear.npy')
x3m = load(matrix_path + 'x_3 linear.npy')

y1m = load(matrix_path + 'y_1 linear.npy')
y2m = load(matrix_path + 'y_2 linear.npy')
y3m = load(matrix_path + 'y_3 linear.npy')

z1m = load(matrix_path + 'z_1 linear.npy')
z2m = load(matrix_path + 'z_2 linear.npy')
z3m = load(matrix_path + 'z_3 linear.npy')

# %% Main program

# Initialize coordinate arrays
x_cord = np.array([])
y_cord = np.array([])
z_cord = np.array([])

# Load video
vid = cv2.VideoCapture(video_path)
currentframe = 0

while (True):

    # reading from frame
    success, frame = vid.read()

    if success:

       # Read x coordinate
       
        # 1st digit
        x1_I = frame[660:671, 1115:1124]
        x1_D = np.matmul(x1m, x1_I.ravel()).argmax()

        # 2nd digit
        x2_I = frame[656:667, 1108:1117]
        x2_D = np.matmul(x2m, x2_I.ravel()).argmax()
        
        # 3rd digit
        x3_I = frame[652:662, 1101:1111]
        x3_D = np.matmul(x3m, x3_I.ravel()).argmax()
        
        # Combine digits
        x_N = 100 * x3_D + 10 * x2_D + x1_D
        
        # Save to array
        x_cord = np.append(x_cord, x_N)

        # Read y coordinate
        y1_I = frame[665:675, 1161:1168]
        y1_D = np.matmul(y1m, y1_I.ravel()).argmax()

        y2_I = frame[666:677, 1153:1161]
        y2_D = np.matmul(y2m, y2_I.ravel()).argmax()

        y3_I = frame[667:678, 1145:1153]
        y3_D = np.matmul(y3m, y3_I.ravel()).argmax()

        y_N = 100 * y3_D + 10 * y2_D + y1_D

        y_cord = np.append(y_cord, y_N)

        # Read z coordinate
        z1_I = frame[641:651, 1201:1209]
        z1_D = np.matmul(z1m, z1_I.ravel()).argmax()

        z2_I = frame[647:657, 1195:1203]
        z2_D = np.matmul(z2m, z2_I.ravel()).argmax()

        z3_I = frame[652:662, 1190:1198]
        z3_D = np.matmul(z3m, z3_I.ravel()).argmax()

        z_N = 100 * z3_D + 10 * z2_D + z1_D

        z_cord = np.append(z_cord, z_N)

    else:
        break

# Release all space and windows once done
vid.release()
cv2.destroyAllWindows()

# %% Create time array

FPS = 30
t = np.arange(0, x_cord.size, 1) / FPS

# %% Save unaltered trajectory

# Save as csv
savetxt(save_path + csv_name, np.array([t,x_cord,y_cord,z_cord]).T, delimiter=',')

# Save as numpy array
save(save_path + npy_name, np.array([t,x_cord,y_cord,z_cord]))

''' Use something like this to load in a separate file for analysis:
   
import numpy as np
from numpy import load

traj = load(save_path + npy_name)

t, x, y, z = traj

'''

# %%
'''Only keeps points where each coordinate has changed by less than the 
 threshold value between frames. If several frames in a row are wrong, this 
 can be iterated until they are all removed, but make sure the threshold is 
enough to not remove valid points. For example if the threshold is 3, and 5 
frames in a row are wrong and Link is moving at 2 meters per frame, the correct
frames outside the wrong frames will be more than 3 apart, so will be removed if 
this is iterated too many times '''

thresh = 10


def clean(t, x, y, z):

    # this results in xd[i] = x[i] - x[i-1]
    xd = np.append(0, np.diff(x))
    yd = np.append(0, np.diff(y))
    zd = np.append(0, np.diff(z))

    cln = (abs(xd) < thresh) * (abs(yd) < thresh) * (abs(zd) < thresh)
    return t[cln], x[cln], y[cln], z[cln]

# Plot the trajectory to see if further iterations are necessary
tc, xc, yc, zc = clean(t, x_cord, y_cord, z_cord)
tc, xc, yc, zc = clean(tc, xc, yc, zc)
tc, xc, yc, zc = clean(tc, xc, yc, zc)
tc, xc, yc, zc = clean(tc, xc, yc, zc)

# %% Save corrected trajectory

# csv
savetxt(save_path + csv_corrected_name, np.array([tc,xc,yc,zc]).T, delimiter=',')

# npy
save(save_path + csv_corrected_name, np.array([tc,xc,yc,zc]))

# %% Plot measured and corrected individual coordinate measurements

fig, axes = plt.subplots(3)

ax = axes[0]
ax.plot(t, x_cord, label='Measured')
ax.plot(tc, xc, label='Corrected', c='g')
ax.title.set_text('x Position')
ax.legend()

ax = axes[1]
ax.plot(t, y_cord)
ax.plot(tc, yc, c='g')
ax.title.set_text('y Position')

ax = axes[2]
ax.plot(t, z_cord)
ax.plot(tc, zc, c='g')
ax.title.set_text('z Position')

plt.subplots_adjust(hspace=0.5,top=0.875)


# %% Plot corrected full 3d path

fig2 = plt.subplots()
ax = plt.axes(projection='3d')
ax.plot3D(xc, yc, zc, 'green')
plt.show()

# %% Create gif of 3d plot rotating


fig3, ax = plt.subplots(subplot_kw={"projection": "3d"})
ax.plot3D(xc, yc, zc, 'green')
ax.view_init(elev=10, azim=0)


def animate(i):
    ax.view_init(elev=10, azim=3*i)
    
# Path to save gif

ani = animation.FuncAnimation(fig3, animate, frames=120, interval=50)

# uncomment to save gif
#ani.save(save_path + 'spiral.gif', writer='pillow', fps=30, dpi=100)

#%%
